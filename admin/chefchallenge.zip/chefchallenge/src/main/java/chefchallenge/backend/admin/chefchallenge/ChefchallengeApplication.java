package chefchallenge.backend.admin.chefchallenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChefchallengeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChefchallengeApplication.class, args);
	}

}
