package chefchallenge.backend.admin.chefchallenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChefchallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
